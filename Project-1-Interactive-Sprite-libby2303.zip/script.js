/**
 * Project 1 - Interactive Image
 * Name: Libby Richter 10/9/2022
 * Comments: Drawing of Koya the koala, future main character of game, Koya will move with the cursor when mouse is clicked
 */

// Global Variables go here
let x
let y


function setup(){
  // this function will run once
  createCanvas(600, 400); // create a 600x400 pixel drawing canvas
x = 0
y = 0
  
}

function draw(){
  // this function runs again and again (60x per second)
  background(255); //white background

  translate(x,y); // x and y are declared and initialized properly ```
  
 // Koya the koala
stroke(107,229,244);
fill(107,229,244); // entire body color
  ellipse(x+300,y+200,200,150); // head 
  rect(x+254,y+211,95,150,35); // torso
  ellipse(x+217,y+155,100); // left ear
  ellipse(x+382,y+155,100); // right ear
  rect(x+263,y+335,30,50,35); // left leg
  rect(x+309,y+335,30,50,35); // right leg
  rect(x+221,y+270,50,30,35); // left arm
  rect(x+331,y+270,50,30,35); // right arm. final shape for general body. 
stroke(255);
fill(255); // belly fur color
  ellipse(x+300,y+310,55,75); // belly  
stroke(176,122,255);
fill(176,122,255); // nose color
  ellipse(x+301,y+200,46,30); // nose
stroke(0);
fill(0); // eye color
  ellipse(x+258,y+182,20,22); // left eye
  ellipse(x+342,y+182,20,22); // right eye
 
  if(mouseIsPressed){
    x = mouseX;
    y = mouseY;
  } else {
    x = 0
    y = 0
  // This if else statement allows Koya to follow the cursor around the canvas when the mouse is clicked
}
  }


